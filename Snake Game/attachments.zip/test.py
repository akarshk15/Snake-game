ch = int(input())

if ch == 1:
   from SNAKE import *
   gameloop()
if ch == 2:
    from corona import *
    loop()
else:
    print("invalid")



